import installExternalComponents from './install_components'

export default {
  install: (Vue, opts = {}) => {
    installExternalComponents(Vue)
  }
}
