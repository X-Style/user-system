const mutations = {
  login (state, data) {
    console.log(data)
  }
}

export default mutations
